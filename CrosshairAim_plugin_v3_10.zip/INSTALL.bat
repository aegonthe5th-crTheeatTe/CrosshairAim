@echo off
rem Installs CrosshairAim as a Pulsar local plugin: Local\CrosshairAim\plugin.dll
rem The files are re-written from bytes so Windows' "downloaded from the internet" mark is NOT carried over (that mark makes the game refuse to load the DLL).
set "DEST=%AppData%\Pulsar\Legacy\Local\CrosshairAim"
set "SRC=%~dp0CrosshairAim"
if not exist "%DEST%" mkdir "%DEST%"
del /Q "%AppData%\Pulsar\Legacy\Local\CrosshairAim.dll" "%AppData%\Pulsar\Legacy\Local\CrosshairAim.xml" 2>nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "foreach($n in 'plugin.dll','plugin.xml'){ $b=[IO.File]::ReadAllBytes((Join-Path '%SRC%' $n)); [IO.File]::WriteAllBytes((Join-Path '%DEST%' $n),$b) }; Get-ChildItem '%DEST%' | Unblock-File; Write-Host 'Installed to %DEST%'"
if errorlevel 1 (echo Install failed. Close the game and try again.)
echo Next: start through Pulsar, open the Plugin List button, search CrosshairAim, tick it.
pause
