v3.10: gun marker ignores guns not pointing forward; weapon slots select guns of that type; on foot weapon spread angles go to OTS+ for the dynamic cursor.
v3.9.2: mode 3 no longer stalls when the cursor is below the ship or the bank passes 90 degrees (roll target folds back, pitch can push down); gun marker reflection cached per gun type (fixes "Object does not match target type"); mode 3 log line now shows theta, blend, errors.
v3.9.1: gun marker falls back to every fixed gun when nothing usable is selected, and logs why a gun gave no muzzle.
v3.9: Q/E roll in the mouse-aim modes, gentler mode 3 (Aggressiveness), and the selected guns real muzzle data for the OTS+ gun marker, flight HUD and lead marker. Needs OTS+ test 24.

v3.8: fixed door/button use patches on older Harmony (MoveLabelsFrom missing).

CrosshairAim (Pulsar plugin) - companion to Over The Shoulder+ and "Take cover or die".

Install: unzip, run INSTALL.bat. It puts the plugin at
  %AppData%\Pulsar\Legacy\Local\CrosshairAim\plugin.dll  (+ plugin.xml)
Manual: copy the CrosshairAim folder into %AppData%\Pulsar\Legacy\Local, then right-click both files > Properties > Unblock.
Start the game through Pulsar, open the PLUGIN LIST button (search CrosshairAim), tick it, apply and restart. Local plugins must be ticked there like any other.
If it is missing, send %AppData%\Pulsar\Legacy\info.log and the SpaceEngineers log lines containing "[CrosshairAim]".
Source/CrosshairAim.cs is the full source.

v3.4: adds the walk override for the cover mod v9.3 (A / D walk along cover, W / S and Space do nothing in cover). Log line: [CrosshairAim] walk patch applied.

v3.5: hides the game's crosshair while the cover mod shows its red one (hostile under the crosshair), and blocks the game's jump while you are in cover. Log lines: [CrosshairAim] crosshair patch applied, jump patch applied.

v3.8: the Airplane swap now happens at the gyro control so it cannot be skipped; new steering mode 3 (bank-and-pull aim); OTS+ test 23 needed.
v3.7: ship steering modes for OTS+ test 20: Airplane (controls swapped: mouse left/right rolls, Q/E yaw, A/D strafe as usual, plus level-out and turn-with-bank helpers that act only when you give no input, under gravity) and Mouse aim (the ship turns to the camera). Closed loop on the gyro control, so it does not depend on ship size. Log lines start with "[CrosshairAim] steering"; send them if the ship misbehaves. A safety pauses the mode for 10 s if the controls seem to push the wrong way.
